<? 
require_once('app/app.php');
?>